async function getInfo() {
    
    const stopNameElement = document.getElementById('stopName');
    const timeTableElement = document.getElementById('buses');

    const stopId = document.getElementById('stopId').value;
    const BASE_URL = `http://localhost:3030/jsonstore/bus/businfo/${stopId}`;

    try {
        timeTableElement.innerHTML = '';        
        const res = await fetch (BASE_URL);
        const data = await res.json();

        if (res.status !== 200) {
            throw new Error('StopId not found')
        }

        stopNameElement.textContent = data.name;

        Object.entries(data.buses).forEach(bus => {
            const liItem = document.createElement('li');
            liItem.textContent = `Bus ${bus[0]} arrives in ${bus[1]} minutes`
            timeTableElement.appendChild(liItem);
        });        

    }catch (error) {
        stopNameElement.textContent = 'Error';
    }
}
